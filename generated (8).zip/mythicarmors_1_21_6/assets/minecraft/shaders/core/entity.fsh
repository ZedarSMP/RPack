#version 150
#define OC_EMISSIVE_INTENSITY 1.1
#moj_import <minecraft:fog.glsl>
#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#moj_import <minecraft:light.glsl>
#endif
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
uniform sampler2D Sampler0;
#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
in vec4 vertexPerFaceColorBack;
in vec4 vertexPerFaceColorFront;
#else
in vec4 vertexColor;
#endif
in vec4 lightColor;
in vec4 overlayColor;
in vec2 texCoord;
in vec4 texCoord2;
in vec3 Pos;
in float transition;
flat in int isCustom;
flat in int noshadow;
flat in vec4 ocTint;
flat in int ocLayerFlags;
flat in float ocEmissMaskV;
flat in float ocTintMaskV;
out vec4 fragColor;
#moj_import <mythicarmors_glint.glsl>
void main() {
#ifndef OC_NO_INVERTED_CUBES
    if (isCustom == 1 && !gl_FrontFacing) discard;
#endif
    vec4 tex = transition > 0.0
        ? mix(texture(Sampler0, texCoord), texture(Sampler0, texCoord2.xy), transition)
        : texture(Sampler0, texCoord);
    vec4 color = tex;
    bool ocEmissive = false;
    bool ocTintable = false;
    if (isCustom == 1 && tex.a > 0.0) {
        ocEmissive = ((ocLayerFlags & 1) != 0) ||
            (ocEmissMaskV > 0.0 && texture(Sampler0, vec2(texCoord.x, texCoord.y + ocEmissMaskV)).a > 0.0);
        ocTintable = ((ocLayerFlags & 2) != 0) ||
            (ocTintMaskV > 0.0 && ((ocTintMaskV == ocEmissMaskV && (ocLayerFlags & 1) == 0)
                ? ocEmissive
                : texture(Sampler0, vec2(texCoord.x, texCoord.y + ocTintMaskV)).a > 0.0));
    }
    vec3 ocBase = ocTintable ? tex.rgb * ocTint.rgb : tex.rgb;
    if (ocTintable) { color.rgb = ocBase; color.a = 1.0; }
    #define ENTITY
    #moj_import<mythicarmors_light.glsl>
    if (ocEmissive) { color.rgb = ocBase * OC_EMISSIVE_INTENSITY; color.a = 1.0; }
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) discard;
#endif
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
    if ((ocLayerFlags & 4) != 0) color.rgb += ocGlintColor(vec3(texCoord2.zw, GlintAlpha));
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
