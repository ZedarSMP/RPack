float ocGlintHash(uint n) {
    n = (n ^ 61u) ^ (n >> 16u);
    n *= 9u;
    n ^= n >> 4u;
    n *= 668265261u;
    n ^= n >> 15u;
    return float(n & 65535u) / 65535.0;
}
float ocGlintBand(float t, uint cells, uint seed) {
    float x = fract(t) * float(cells);
    uint i = uint(x);
    float f = x - float(i);
    float v = mix(ocGlintHash(i % cells + seed), ocGlintHash((i + 1u) % cells + seed), f * f * (3.0 - 2.0 * f));
    return v * v * v;
}
vec3 ocGlintColor(vec3 g) {
    float b = 0.4 * ocGlintBand(g.x * 2.0, 16u, 109u) + 0.3 * ocGlintBand((g.y + 0.5 * g.x) * 2.0, 8u, 303u);
    vec3 c = g.z * vec3(1.2 * b * b, 0.15 * b + 0.2 * b * b, b);
    return c * c;
}
