//objmc
//https://github.com/Godlander/objmc


float ocEntityScale(float wW, float wH, float tW, float tH, float gSquare) {
    if (tW < 0.001 || tH < 0.001) return 1.0;
    if (abs(wW - wH) < 0.001) return wW / (tW + 2.0 * gSquare);
    float inflate = (wH * tW - wW * tH) / (2.0 * (wW - wH));
    return wW / (tW + 2.0 * inflate);
}
#if defined(GL_KHR_shader_subgroup_basic) && defined(GL_KHR_shader_subgroup_ballot) && defined(GL_KHR_shader_subgroup_shuffle)
bool ocQuadCheck(int ocVid, int ac, int ocLane0, bool ocInRange) {
    uvec4 ocActive = subgroupBallot(true);
    bool ocQuad = ocInRange;
    for (int k = 0; k < 4; k++) {
        uint lk = ocInRange ? uint(ocLane0 + k) : gl_SubgroupInvocationID;
        bool ocLaneOn = subgroupBallotBitExtract(ocActive, lk);
        int ocSib = subgroupShuffle(ocVid, ocLaneOn ? lk : gl_SubgroupInvocationID);
        if (!ocLaneOn || ocSib != ocVid - ac + k) ocQuad = false;
    }
    return ocQuad;
}
#endif
ivec4 getmeta(ivec2 topleft, int offset) {
    return ivec4(texelFetch(Sampler0, topleft + ivec2(offset,0), 0) * 255.0 + 0.5);
}
vec3 getpos(ivec2 topleft, int w, int h, int index) {
    uint i = uint(index*3);
    uint uw = uint(w);
    uint cy = i / uw;
    uint cx = i - cy*uw;
    vec4 x = texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0);
    cx++; if (cx == uw) { cx = 0u; cy++; }
    vec4 y = texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0);
    cx++; if (cx == uw) { cx = 0u; cy++; }
    vec4 z = texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0);
    return vec3(
        (x.r*256)+(x.g)+(x.b/256),
        (y.r*256)+(y.g)+(y.b/256),
        (z.r*256)+(z.g)+(z.b/256)
    )*(255./256.) - vec3(128);
}
vec2 getuv(ivec2 topleft, int w, int h, int index) {
    uint i = uint(index*2);
    uint uw = uint(w);
    uint cy = i / uw;
    uint cx = i - cy*uw;
    vec4 x = texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0);
    cx++; if (cx == uw) { cx = 0u; cy++; }
    vec4 y = texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0);
    return vec2(
        ((x.g*65280)+(x.b*255))/65535,
        ((y.g*65280)+(y.b*255))/65535
    );
}
ivec2 getvert(ivec2 topleft, int w, int h, int index) {
    uint i = uint(index*2);
    uint uw = uint(w);
    uint cy = i / uw;
    uint cx = i - cy*uw;
    ivec4 a = ivec4(texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0)*255.0+0.5);
    cx++; if (cx == uw) { cx = 0u; cy++; }
    ivec4 b = ivec4(texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0)*255.0+0.5);
    return ivec2(
        ((a.r*65536)+(a.g*256)+a.b),
        ((b.r*65536)+(b.g*256)+b.b)
    );
}
bool getb(int i, int b) {
    return bool((i>>b)&1);
}
int getb(int i, int b, int s) {
    return (i>>b)&((1<<s)-1);
}
vec3 bezb(vec3 a, vec3 b, vec3 c, vec3 d, float t) {
    float t2 = t * t;
    float t3 = t2 * t;
    return (d-3*c+3*b-a)*t3 + (3*c-6*b+3*a)*t2 + (3*b-3*a)*t + a;
}
vec3 bezier(vec3 a, vec3 b, vec3 c, vec3 d, float t) {
    return bezb(b,b+(c-a)/6,c-(d-b)/6,c,t);
}
