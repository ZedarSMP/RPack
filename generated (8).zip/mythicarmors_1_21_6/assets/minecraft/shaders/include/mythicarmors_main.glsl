//objmc
//https://github.com/Godlander/objmc

isCustom = 0;
transition = 0;
ocLayerFlags = 0;
ocEmissMaskV = 0.0;
ocTintMaskV  = 0.0;
noshadow = 0;
texCoord2 = vec4(0.0);
// Hidden carrier quads collapse to a point and emit no fragments, so the
// importer may skip fragment-only work.
bool ocHidden = false;
#ifdef ENTITY
#define OC_VARIANT_SKELETON 254
#ifndef OC_LEG_INFLATE
#define OC_LEG_INFLATE 0.5
#endif
#ifndef OC_FOOT_INFLATE
#define OC_FOOT_INFLATE 1.0
#endif
if (isCustom == 0) {
    ivec4 am = ivec4(texelFetch(Sampler0, ivec2(0,0), 0)*255.0+0.5);
    bool ocMarker = am.rgb == ivec3(12,34,56);
    if (ocMarker) {
        ivec4 ocSz = ivec4(texelFetch(Sampler0, ivec2(0,1), 0)*255.0+0.5);
        ocMarker = textureSize(Sampler0, 0) == ivec2(ocSz.r*256+ocSz.g, ocSz.b*256+ocSz.a);
    }
    bool ocPacked = ocMarker && (am.a == 254 || am.a == 253);
// shaderc predefines VULKAN and only declares gl_BaseVertexARB from GLSL 4.40,
// so below that a Vulkan client takes the hidden branch rather than failing to
// compile, which would take every entity pipeline down with it.
#if defined(GL_KHR_shader_subgroup_basic) && defined(GL_KHR_shader_subgroup_ballot) && defined(GL_KHR_shader_subgroup_shuffle) && defined(GL_ARB_shader_draw_parameters) && (!defined(VULKAN) || __VERSION__ >= 440)
#ifdef VULKAN
#define OC_VERTEX_ID gl_VertexIndex
#else
#define OC_VERTEX_ID gl_VertexID
#endif
    int ocVid = OC_VERTEX_ID - gl_BaseVertexARB;
    int ac = ocVid & 3;
    int ocLane0 = int(gl_SubgroupInvocationID) - ac;
    bool ocInRange = ocLane0 >= 0 && ocLane0 + 3 < int(gl_SubgroupSize);
    if (ocPacked) {
        isCustom = 1;
        // Staged by fetch cost: LOD (0 fetches) -> slot (1) -> face key (1-2)
        // -> full decode. Every branch condition is identical across a carrier
        // quad's 4 lanes, keeping subgroupShuffle face-uniform.
        ivec2 ao = ivec2(0);
        uint ocQ = uint(ocVid) >> 2;
        int f6 = int(ocQ % 6u);
        ivec4 t8 = getmeta(ao, 8);
        int nboxes = max(t8.a, 1);
        int abody = int((ocQ / 6u) % uint(nboxes));
        int ocVariant = int(Color.r * 255.0 + 0.5);
        if (ocVariant == OC_VARIANT_SKELETON && nboxes >= 3) {
            if (abody == 1) abody = 2;
            else if (abody == 2) abody = 1;
        }
        ivec4 tb = (abody == 0) ? t8 : getmeta(ao, 8 + abody);
        int atarget = tb.b;
        if (atarget < 0 || atarget > 7) atarget = 0;
        int afk = 65535;
        if      (f6 == 3) afk = tb.r * 256 + tb.g;
        else if (f6 == 5) { ivec4 m = getmeta(ao, 11 + abody); afk = m.r * 256 + m.g; }
        else if (f6 == 2) { ivec4 m = getmeta(ao, 14 + abody); afk = m.r * 256 + m.g; }
        else if (f6 == 4) { ivec4 m = getmeta(ao, 17 + abody); afk = m.r * 256 + m.g; }
        else if (f6 == 0) { ivec4 m = getmeta(ao, 23 + abody); afk = m.r * 256 + m.g; }
        else              { ivec4 m = getmeta(ao, 23 + abody); afk = 65535 - (m.b * 256 + m.a); }
        bool hide = (afk == 65535);
        if (!hide) hide = !ocQuadCheck(ocVid, ac, ocLane0, ocInRange);
        if (hide) {
            Pos = vec3(9999.0);
            ocHidden = true;
        } else {
            ivec4 t[8];
            for (int i = 1; i < 8; i++) if (i != 4) t[i] = getmeta(ao, i);
            ivec2 as = ivec2(t[1].r*256+t[1].g, t[1].b*256+t[7].r);
            int anv = t[2].r*16777216+t[2].g*65536+t[2].b*256+t[7].g;
            int anf = max(t[3].r*65536+t[3].g*256+t[3].b, 1);
            int ant = max(t[3].a, 1);
            t[4] = ivec4(0);
            int avph = t[5].r*256+t[5].g;
            int avth = t[5].b*256+t[7].b;
            noshadow = getb(t[6].r, 7, 1);
            float adur = 1.0;
            float at = 0.0;
            int afr = 0;
            if (anf > 1) {
                t[4] = getmeta(ao, 4);
                adur = max(float(t[4].r*65536+t[4].g*256+t[4].b), 1.0);
                bool aap = getb(t[4].a, 6);
                at = GameTime * 24000.0;
                at = aap ? at + adur : 0.0;
                afr = int(at * float(anf) / adur) % anf;
            }
            ivec2 atlasSize = textureSize(Sampler0, 0);
            vec2 onepixel = 1./atlasSize;
            ivec4 df = getmeta(ao, 26 + abody);
            int ocEOff = df.r * 256 + df.g;
            int ocTOff = df.b * 256 + df.a;
            if      (ocEOff == 65535) ocLayerFlags |= 1;
            else if (ocEOff  > 0)     ocEmissMaskV = float(ocEOff) / float(atlasSize.y);
            if      (ocTOff == 65535) ocLayerFlags |= 2;
            else if (ocTOff  > 0)     ocTintMaskV  = float(ocTOff) / float(atlasSize.y);
            int aemis = 0;
            if (noshadow == 0 && f6 >= 2) {
                ivec4 em = getmeta(ao, 20 + abody);
                aemis = (f6 == 3) ? em.r
                      : (f6 == 5) ? em.g
                      : (f6 == 2) ? em.b
                      : em.a;
            }
            bool aleft = (atarget == 3 || atarget == 5 || atarget == 7);
            const vec3 AOFF[8] = vec3[8](
                vec3(0.2925, -0.785,  -0.188),
                vec3(0.2925, -0.045, -0.2925),
                vec3(0.25,  -0.69,  -0.188),
                vec3(0.25,  0.135,   -0.188),
                vec3(0.15,   -0.775,   -0.15),
                vec3(0.15,   -0.025,   -0.15),
                vec3(0.17,   -0.804, -0.17),
                vec3(0.17,   0.004,  -0.17)
            );
            const float ADWs[8] = float[8]( 2.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 );
            const float ADHs[8] = float[8]( -1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 );
            const float ADWe[8] = float[8]( 0.5, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 );
            const float ADHe[8] = float[8]( 0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 );
            const float AKH[8] = float[8]( 0.25, 0.25, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5 );
            if (aemis > 0) noshadow = 1;
            int avbase = (afk * 4 + ac) % anv;
            int avid = avbase + afr * anv;
            int ahh = 2 + int(ceil(float(anv)*0.25/float(as.x)));
            int ah = ahh + (as.y * ant);
            ivec2 ai = getvert(ao, as.x, ah+avph+avth, avid);
            vec3 posoffset = getpos(ao, as.x, ah, ai.x);
            if (anf > 1) {
                ivec2 aeasing = ivec2(getb(t[4].a, 4, 2), getb(t[4].a, 2, 2));
                if (aeasing.x > 0) {
                    float atr = fract(at * float(anf) / adur);
                    vec3 po2 = getpos(ao, as.x, ah, getvert(ao, as.x, ah+avph+avth, avbase + ((afr + 1) % anf) * anv).x);
                    if (aeasing.x == 3) {
                        vec3 po3 = getpos(ao, as.x, ah, getvert(ao, as.x, ah+avph+avth, avbase + ((afr + 2) % anf) * anv).x);
                        vec3 po4 = getpos(ao, as.x, ah, getvert(ao, as.x, ah+avph+avth, avbase + ((afr + 3) % anf) * anv).x);
                        posoffset = bezier(posoffset, po2, po3, po4, atr);
                    } else {
                        if (aeasing.x == 2) atr = atr < 0.5 ? 4.0 * atr * atr * atr : 1.0 - pow(-2.0 * atr + 2.0, 3.0) * 0.5;
                        posoffset = mix(posoffset, po2, atr);
                    }
                }
            }
            if ((int(Color.b * 255.0 + 0.5) & 1) == 1) {
                vec2 ocG = vec2((posoffset.x + 2.0 * posoffset.z) * 0.04 + float(atarget) * 0.06, posoffset.y * -0.08);
                ocLayerFlags |= 4;
                texCoord2.zw = vec2(0.98480775 * ocG.x - 0.17364818 * ocG.y - fract(GameTime * 44.0),
                                    0.17364818 * ocG.x + 0.98480775 * ocG.y + fract(GameTime * 160.0));
            }
            vec2 auv = getuv(ao, as.x, ah+avph, ai.y);
            vec2 ajit = vec2(onepixel.x*0.0001*float(ac), onepixel.y*0.0001*float((ac+1)&3));
            texCoord = (vec2(0, ahh) + auv*vec2(as))/vec2(atlasSize) + ajit;
            if (ant > 1) {
                ivec4 texmeta  = ivec4(texelFetch(Sampler0, ao + ivec2(4,1), 0)*255.0+0.5);
                ivec4 texflags = ivec4(texelFetch(Sampler0, ao + ivec2(5,1), 0)*255.0+0.5);
                float texFrametime = max(float(texmeta.r*65536 + texmeta.g*256 + texmeta.b), 1.0);
                float texTime = GameTime * 24000.0;
                int texframe = int(texTime / texFrametime) % ant;
                int texnext  = (texframe + 1) % ant;
                texCoord  = (vec2(0, ahh + texframe*as.y) + auv*vec2(as))/vec2(atlasSize) + ajit;
                texCoord2.xy = (vec2(0, ahh + texnext *as.y) + auv*vec2(as))/vec2(atlasSize) + ajit;
                transition = bool(texflags.r) ? fract(texTime / texFrametime) : 0.0;
            }
            if (aleft) posoffset.x = -posoffset.x;
            posoffset -= AOFF[atarget];
            if (aleft) posoffset.y -= 0.05;
            if (atarget == 0) posoffset.x -= 0.02;
            if (atarget == 0) {
                bool aLegLayer = false;
                for (int b = 0; b < nboxes; b++) {
                    if (b == abody) continue;
                    int bp = ((b == 0) ? t8 : getmeta(ao, 8 + b)).b;
                    if (bp == 4 || bp == 5) { aLegLayer = true; break; }
                }
                if (aLegLayer) posoffset -= vec3(-0.0293, 0.0293, 0.0293);
            }
            uint ocL = uint(ocLane0);
            vec3 ocP[4];
            vec2 ocT[4];
            for (int k = 0; k < 4; k++) {
                ocP[k] = subgroupShuffle(Position, ocL + uint(k));
                ocT[k] = subgroupShuffle(UV0, ocL + uint(k));
            }
            vec2 ocTmin = min(min(ocT[0], ocT[1]), min(ocT[2], ocT[3]));
            vec2 ocTmax = max(max(ocT[0], ocT[1]), max(ocT[2], ocT[3]));
            vec2 ocTsize = (ocTmax - ocTmin) * vec2(64.0, 32.0);
            float ocUmin = ocTmin.x * 64.0;
            float ocU0 = (ocUmin >= 36.0) ? 40.0 : (ocUmin >= 14.0) ? 16.0 : 0.0;
            float ocSx = (ocU0 == 16.0) ? 8.0 : 4.0;
            int f6geo = (ocTmin.y * 32.0 < 18.0)
                ? ((ocUmin < ocU0 + 4.0 + 0.5 * ocSx) ? 0 : 1)
                : ((ocUmin < ocU0 + 2.0) ? 2 : (ocUmin < ocU0 + 4.0 + 0.5 * ocSx) ? 3 : (ocUmin < ocU0 + 6.0 + ocSx) ? 4 : 5);
            vec2 ocMid = 0.5 * (ocTmin + ocTmax);
            vec3 ocC[4];
            int ocCi0 = 0;
            int ocCi1 = 0;
            for (int k = 0; k < 4; k++) {
                bool ocRight = ocT[k].x > ocMid.x;
                bool ocTop = (f6geo == 1) ? (ocT[k].y > ocMid.y) : (ocT[k].y < ocMid.y);
                int ci = ocRight ? (ocTop ? 0 : 3) : (ocTop ? 1 : 2);
                ocC[ci] = ocP[k];
                if (k == 0) ocCi0 = ci;
                if (k == 1) ocCi1 = ci;
            }
            if (ocTmin.y * 32.0 < 8.0 || ocTsize.x < 0.5 || ocTsize.y < 0.5) {
                Pos = vec3(9999.0);
                ocHidden = true;
            } else {
            bool ocMirror = (ocCi0 == 3 && ocCi1 == 2) ? true : (ocCi0 == 0 && ocCi1 == 1) ? false : aleft;
            vec3 a0 = ocMirror ? ocC[3] : ocC[0];
            vec3 a1 = ocMirror ? ocC[2] : ocC[1];
            vec3 a2 = ocMirror ? ocC[1] : ocC[2];
            vec3 a3 = ocMirror ? ocC[0] : ocC[3];
            vec3 d1 = a0 - a1;
            vec3 d3 = a0 - a3;
            float lenW = length(d1);
            float lenH = length(d3);
            float ocScale = ocEntityScale(lenW * 16.0, lenH * 16.0, ocTsize.x, ocTsize.y,
                (atarget == 4 || atarget == 5) ? OC_LEG_INFLATE : (atarget == 6 || atarget == 7) ? OC_FOOT_INFLATE : 1.0);
            vec3 e1 = normalize(d1);
            vec3 e2 = normalize(d3);
            e2 = normalize(e2 - dot(e2, e1) * e1);
            // GUI picture-in-picture passes are the only orthographic ProjMat
            // (m23 == 0; world is perspective, m23 == -1) and bake a mirrored
            // pose into Position; cross() flips under a mirror, so correct its
            // sign there. Winding still matches: the ortho y-flip cancels the
            // pose's z-mirror on screen.
            vec3 cr = cross(e1, e2);
            if (ProjMat[2][3] == 0.0) cr = -cr;
            // Columns of abasis * CF written out directly: the per-face frame
            // matrices are signed axis permutations, so the product is a column
            // pick with sign flips, exactly equal to the multiply it replaces.
            vec3 se2 = ocMirror ? -e2 : e2;
            mat3 abasisBox = (f6geo == 5) ? mat3( e1, se2,  cr)
                           : (f6geo == 2) ? mat3( cr, se2, -e1)
                           : (f6geo == 4) ? mat3(-cr, se2,  e1)
                           : (f6geo == 0) ? mat3(-e1,  cr, se2)
                           : (f6geo == 1) ? mat3(-e1, -cr, -se2)
                           :                mat3(-e1, se2, -cr);
            posoffset = abasisBox * posoffset;
            vec3 n = cr;
            float akOff = lenW + AKH[atarget] * ocScale;
            vec3 anchor;
            if      (f6geo == 3) anchor = a2;
            else if (f6geo == 0) anchor = ocMirror ? a1 : a2 - akOff * n;
            else if (f6geo == 1) anchor = ocMirror ? a2 - akOff * n : a1;
            else if (f6geo == 2) anchor = a2 + d1;
            else if (f6geo == 5) anchor = a2 + d1
                              - (ADWs[atarget]*lenW + ADHs[atarget]*lenH) * n;
            else              anchor = a2
                              - (ADWe[atarget]*lenW + ADHe[atarget]*lenH) * n;
            Pos = anchor + posoffset * ocScale;
            }
            }
    } else if (ocMarker && am.a == 252) {
        int f6 = (ocVid >> 2) % 6;
        if (f6 != 3 && f6 != 5) {
            Pos = vec3(9999.0);
            ocHidden = true;
        } else if (ocQuadCheck(ocVid, ac, ocLane0, ocInRange)) {
            Pos = vec3(9999.0);
            ocHidden = true;
        }
    }
#else
    if (ocPacked) {
        isCustom = 1;
        Pos = vec3(9999.0);
        ocHidden = true;
    }
#endif
}
#endif
