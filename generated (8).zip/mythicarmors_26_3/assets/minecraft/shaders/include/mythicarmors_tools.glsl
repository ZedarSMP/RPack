//objmc
//https://github.com/Godlander/objmc


float ocEntityScale(float wW, float wH, float tW, float tH, float gSquare) {
    if (tW < 0.001 || tH < 0.001) return 1.0;
    if (abs(wW - wH) < 0.001) return wW / (tW + 2.0 * gSquare);
    float inflate = (wH * tW - wW * tH) / (2.0 * (wW - wH));
    return wW / (tW + 2.0 * inflate);
}
#ifdef OC_SUBGROUP
vec3 ocP[4];
vec2 ocT[4];
bool ocDiag;
bool ocExact;
#define OC_LANE(L) if (uint(L) < gl_SubgroupSize && subgroupBallotBitExtract(ocActive, uint(L))) { vec4 ocBa = subgroupBroadcast(ocA, uint(L)); vec2 ocBt = subgroupBroadcast(UV0, uint(L)); int ocRel = int(ocBa.w) - ocVid0; if (ocRel >= 0 && ocRel < 4) { ocP[ocRel] = ocBa.xyz; ocT[ocRel] = ocBt; ocFound |= 1 << ocRel; } }
bool ocQuadCheck(int ocVid, int ac) {
    uvec4 ocActive = subgroupBallot(true);
    vec4 ocA = vec4(Position, float(ocVid));
    int ocVid0 = ocVid - ac;
    int ocFound = 0;
    OC_LANE(0) OC_LANE(1) OC_LANE(2) OC_LANE(3) OC_LANE(4) OC_LANE(5) OC_LANE(6) OC_LANE(7) OC_LANE(8) OC_LANE(9) OC_LANE(10) OC_LANE(11) OC_LANE(12) OC_LANE(13) OC_LANE(14) OC_LANE(15) OC_LANE(16) OC_LANE(17) OC_LANE(18) OC_LANE(19) OC_LANE(20) OC_LANE(21) OC_LANE(22) OC_LANE(23) OC_LANE(24) OC_LANE(25) OC_LANE(26) OC_LANE(27) OC_LANE(28) OC_LANE(29) OC_LANE(30) OC_LANE(31) OC_LANE(32) OC_LANE(33) OC_LANE(34) OC_LANE(35) OC_LANE(36) OC_LANE(37) OC_LANE(38) OC_LANE(39) OC_LANE(40) OC_LANE(41) OC_LANE(42) OC_LANE(43) OC_LANE(44) OC_LANE(45) OC_LANE(46) OC_LANE(47) OC_LANE(48) OC_LANE(49) OC_LANE(50) OC_LANE(51) OC_LANE(52) OC_LANE(53) OC_LANE(54) OC_LANE(55) OC_LANE(56) OC_LANE(57) OC_LANE(58) OC_LANE(59) OC_LANE(60) OC_LANE(61) OC_LANE(62) OC_LANE(63)
    ocDiag = ocFound == ((1 << ac) | (1 << (ac ^ 2)));
    return ocFound == 15 || ocDiag;
}
const int OC_LBL[24] = int[24](5, 4, 0, 1, 3, 2, 6, 7, 0, 4, 6, 2, 1, 0, 2, 3, 5, 1, 3, 7, 4, 5, 7, 6);
int ocLbl(int f, int k, bool m) {
    return OC_LBL[f * 4 + (m ? 3 - k : k)];
}
#define OC_LANE2(L) if (uint(L) < gl_SubgroupSize && subgroupBallotBitExtract(ocAct, uint(L))) { vec4 ocB = subgroupBroadcast(ocA, uint(L)); int ocW = int(ocB.w); int ocL = ocW & 7; if (ocNeed && uint((ocW >> 3) - ocBox) < 24u) { if (ocL == ocTm) { ocPm = ocB.xyz; ocF |= 1; } if (ocL == ocTn) { ocPn = ocB.xyz; ocF |= 2; } if (ocL == (ocTm ^ ocDm)) { ocPmd = ocB.xyz; ocF |= 4; } if (ocL == (ocTn ^ ocDm)) { ocPnd = ocB.xyz; ocF |= 8; } } }
void ocDiagSolve(bool ocNeed, int ocVid, int ac, int ocPart) {
    int ocBox = (ocVid / 24) * 24;
    bool ocMir = ocPart == 3 || ocPart == 5 || ocPart == 7;
    float ocSx = (ocPart == 0) ? 8.0 : 4.0;
    float ocU0 = (ocPart == 0) ? 16.0 : (ocPart == 2 || ocPart == 3) ? 40.0 : 0.0;
    int ocFc = (ocVid - ocBox) >> 2;
    if (ocFc == 2 || ocFc == 4) ocFc = (UV0.x * 64.0 < ocU0 + 4.0 + 0.5 * ocSx) ? 2 : 4;
    uvec4 ocAct = subgroupBallot(true);
    vec4 ocA = vec4(Position, float(ocVid * 8 + ocLbl(ocFc, ac, ocMir)));
    int ocLo = ac & 1;
    int ocHi = ocLo + 2;
    int ocTm = ocLbl(ocFc, ocLo + 1, ocMir);
    int ocTn = ocLbl(ocFc, (ocLo + 3) & 3, ocMir);
    int ocDm = 7 ^ (ocLbl(ocFc, ocLo, ocMir) ^ ocLbl(ocFc, ocHi, ocMir));
    vec3 ocPm = vec3(0.0);
    vec3 ocPn = vec3(0.0);
    vec3 ocPmd = vec3(0.0);
    vec3 ocPnd = vec3(0.0);
    int ocF = 0;
    OC_LANE2(0) OC_LANE2(1) OC_LANE2(2) OC_LANE2(3) OC_LANE2(4) OC_LANE2(5) OC_LANE2(6) OC_LANE2(7) OC_LANE2(8) OC_LANE2(9) OC_LANE2(10) OC_LANE2(11) OC_LANE2(12) OC_LANE2(13) OC_LANE2(14) OC_LANE2(15) OC_LANE2(16) OC_LANE2(17) OC_LANE2(18) OC_LANE2(19) OC_LANE2(20) OC_LANE2(21) OC_LANE2(22) OC_LANE2(23) OC_LANE2(24) OC_LANE2(25) OC_LANE2(26) OC_LANE2(27) OC_LANE2(28) OC_LANE2(29) OC_LANE2(30) OC_LANE2(31)
    ocExact = false;
    if (ocNeed) {
        vec3 ocSum = ocP[ocLo] + ocP[ocHi];
        if ((ocF & 1) != 0) { ocP[ocLo + 1] = ocPm; ocExact = true; }
        else if ((ocF & 2) != 0) { ocP[ocLo + 1] = ocSum - ocPn; ocExact = true; }
        else if ((ocF & 12) == 12) { ocP[ocLo + 1] = (ocSum + ocPmd - ocPnd) * 0.5; ocExact = true; }
        if (ocExact) ocP[(ocLo + 3) & 3] = ocSum - ocP[ocLo + 1];
    }
}
#endif
ivec4 getmeta(ivec2 topleft, int offset) {
    return ivec4(texelFetch(Sampler0, topleft + ivec2(offset,0), 0) * 255.0 + 0.5);
}
vec3 getpos(ivec2 topleft, int w, int h, int index) {
    uint i = uint(index*3);
    uint uw = uint(w);
    uint cy = i / uw;
    uint cx = i - cy*uw;
    vec4 x = texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0);
    cx++; if (cx == uw) { cx = 0u; cy++; }
    vec4 y = texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0);
    cx++; if (cx == uw) { cx = 0u; cy++; }
    vec4 z = texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0);
    return vec3(
        (x.r*256)+(x.g)+(x.b/256),
        (y.r*256)+(y.g)+(y.b/256),
        (z.r*256)+(z.g)+(z.b/256)
    )*(255./256.) - vec3(128);
}
vec2 getuv(ivec2 topleft, int w, int h, int index) {
    uint i = uint(index*2);
    uint uw = uint(w);
    uint cy = i / uw;
    uint cx = i - cy*uw;
    vec4 x = texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0);
    cx++; if (cx == uw) { cx = 0u; cy++; }
    vec4 y = texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0);
    return vec2(
        ((x.g*65280)+(x.b*255))/65535,
        ((y.g*65280)+(y.b*255))/65535
    );
}
ivec2 getvert(ivec2 topleft, int w, int h, int index) {
    uint i = uint(index*2);
    uint uw = uint(w);
    uint cy = i / uw;
    uint cx = i - cy*uw;
    ivec4 a = ivec4(texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0)*255.0+0.5);
    cx++; if (cx == uw) { cx = 0u; cy++; }
    ivec4 b = ivec4(texelFetch(Sampler0, topleft + ivec2(int(cx), h + int(cy)), 0)*255.0+0.5);
    return ivec2(
        ((a.r*65536)+(a.g*256)+a.b),
        ((b.r*65536)+(b.g*256)+b.b)
    );
}
bool getb(int i, int b) {
    return bool((i>>b)&1);
}
int getb(int i, int b, int s) {
    return (i>>b)&((1<<s)-1);
}
vec3 bezb(vec3 a, vec3 b, vec3 c, vec3 d, float t) {
    float t2 = t * t;
    float t3 = t2 * t;
    return (d-3*c+3*b-a)*t3 + (3*c-6*b+3*a)*t2 + (3*b-3*a)*t + a;
}
vec3 bezier(vec3 a, vec3 b, vec3 c, vec3 d, float t) {
    return bezb(b,b+(c-a)/6,c-(d-b)/6,c,t);
}
