#version 460
#define OC_EMISSIVE_INTENSITY 1.1
#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#include <minecraft:light.glsl>
#endif
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
uniform sampler2D Sampler0;
#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif
#ifdef GLINT
uniform sampler2D GlintSampler;
#endif
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location = 2) in vec4 vertexPerFaceColorBack;
layout(location = 3) in vec4 vertexPerFaceColorFront;
#else
layout(location = 2) in vec4 vertexColor;
#endif
layout(location = 4) in vec4 lightColor;
layout(location = 5) in vec4 overlayColor;
layout(location = 6) in vec2 texCoord;
#ifdef GLINT
layout(location = 7) in vec2 texCoordGlint;
#endif
layout(location = 8) in vec4 texCoord2;
layout(location = 9) in vec4 ocPos;
layout(location = 10) flat in vec4 ocTint;
layout(location = 11) flat in vec4 ocFlat;
#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif
#include <mythicarmors_glint.glsl>

vec4 calculateFinalColor(vec4 color) {
    #ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    #endif

    #ifndef EMISSIVE
    color *= lightColor;
    #endif

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

void main() {
    vec3 Pos = ocPos.xyz;
    float transition = ocPos.w;
    int isCustom = int(ocFlat.w) & 1;
    int noshadow = int(ocFlat.w) >> 1;
    int ocLayerFlags = int(ocFlat.z);
    float ocEmissMaskV = ocFlat.x;
    float ocTintMaskV = ocFlat.y;
    if (isCustom == 0) {
        vec4 color = texture(Sampler0, texCoord);

        #ifdef OIT_ADDITIVE
        color.a = min(0.99, color.a);
        #endif

        #ifdef ALPHA_CUTOUT
        if (color.a < ALPHA_CUTOUT) {
            discard;
        }
        #endif

        #ifdef PER_FACE_LIGHTING
        vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
        #else
        vec4 faceVertexColor = vertexColor;
        #endif

        #ifdef DISSOLVE
        if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord).a) {
            discard;
        }
        faceVertexColor.a = 1.0;
        #endif

        color *= faceVertexColor * ColorModulator;

        #ifdef GLINT
        color.a = max(color.a, GlintAlpha);
        #endif

        #ifdef OIT_ALPHA_ONLY
        executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
        #else
        fragColor = calculateFinalColor(color);
        #endif
        return;
    }
#ifndef OC_NO_INVERTED_CUBES
    if (!gl_FrontFacing) discard;
#endif
    vec4 tex = transition > 0.0
        ? mix(texture(Sampler0, texCoord), texture(Sampler0, texCoord2.xy), transition)
        : texture(Sampler0, texCoord);
    vec4 color = tex;
    bool ocEmissive = false;
    bool ocTintable = false;
    if (tex.a > 0.0) {
        ocEmissive = ((ocLayerFlags & 1) != 0) ||
            (ocEmissMaskV > 0.0 && texture(Sampler0, vec2(texCoord.x, texCoord.y + ocEmissMaskV)).a > 0.0);
        ocTintable = ((ocLayerFlags & 2) != 0) ||
            (ocTintMaskV > 0.0 && ((ocTintMaskV == ocEmissMaskV && (ocLayerFlags & 1) == 0)
                ? ocEmissive
                : texture(Sampler0, vec2(texCoord.x, texCoord.y + ocTintMaskV)).a > 0.0));
    }
    vec3 ocBase = ocTintable ? tex.rgb * ocTint.rgb : tex.rgb;
    if (ocTintable) { color.rgb = ocBase; color.a = 1.0; }
    if (noshadow == 0) {
#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
        vec3 normal = normalize(cross(dFdx(Pos), dFdy(Pos)));
        color *= minecraft_mix_light(Light0_Direction, Light1_Direction, normal, overlayColor);
#endif
        color *= lightColor;
    }
    if (ocEmissive) { color.rgb = ocBase * OC_EMISSIVE_INTENSITY; color.a = 1.0; }
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) discard;
#endif
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
    if ((ocLayerFlags & 4) != 0) color.rgb += ocGlintColor(vec3(texCoord2.zw, GlintAlpha));
#ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
